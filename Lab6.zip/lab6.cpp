#include <stdio.h>
#include <cstdint>
#include <fstream>
#define MAXLEN 100
#define LENGTH 3

int16_t lab1(int16_t a, int16_t b)
{
	int num; // num统计1的个数
	int k = 1;
	for (int i = 0; i < b; i++)
	{
		if ((a & k) == k)
			num++;
		k += k; // 自加表左移
	}
	return num;
}

int16_t lab2(int16_t p, int16_t q, int16_t n)
{
	int F0 = 1, F1 = 1;
	int a = 0, b = 0;
	for (int i = 1; i < n; i++)
	{
		a = F0, b = F1;
		while (a >= 0)
			a = a - p;
		while (b >= 0)
			b = b - q;
		a = a + p;
		b = b + q;
		F0 = F1;
		F1 = a + b;
	}
	return F1;
}

int16_t lab3(int16_t NUM, char string[])
{
	int i;			// R3
	int count = 1;	// R4
	int result = 1; // R2
	for (i = 0; i < NUM; i++)
	{
		if (string[i] == string[i + 1])
			count++;
		else
		{
			if (result < count)
			{
				result = count;
				count = 1;
			}
			else
				continue;
		}
	}
	return result;
}

void lab4(int score[], int *a, int *b)
{
	int num = 16; // R2
	int tmp;
	for (int i = 0; i < num - 1; i++)
	{
		for (int j = 0; j < num - i - 1; j++)
		{
			if (score[j] > score[j + 1])
			{
				tmp = score[j + 1];
				score[j + 1] = score[j];
				score[j] = tmp;
			}
		}
	}
	for (int i = 0; i < num; i++)
	{
		if (score[i] >= 85)
		{
			if (i >= 12)
				(*a)++;
			else if (i >= 8 && i < 12)
				(*b)++;
		}
		else if (score[i] >= 75 && i >= 8)
		{
			(*b)++;
		}
	}
}

int main()
{
	FILE *fp = fopen("test.txt", "r");
	// lab1
	int a = 0, b = 0;
	for (int i = 0; i < LENGTH; ++i)
	{
		fscanf(fp, "%d %d", &a, &b);
		printf("%d\n", lab1(a, b));
	}

	// lab2
	int p = 0, q = 0, n = 0;
	for (int i = 0; i < LENGTH; ++i)
	{
		fscanf(fp, "%d %d %d", &p, &q, &n);
		printf("%d\n", lab2(p, q, n));
	}

	// lab3
	char s[MAXLEN];
	for (int i = 0; i < LENGTH; ++i)
	{
		fscanf(fp, "%d %s", &n, s);
		printf("%d\n", lab3(n, s));
	}

	//lab4
	int score[16];
	for (int i = 0; i < LENGTH; ++i)
	{
		int a = 0, b = 0;
		for (int j = 0; j < 16; ++j)
		{
			fscanf(fp, "%d", &score[j]);
		}
		lab4(score, &a, &b);
		for (int j = 0; j < 16; j++)
		{
			printf("%d ", score[j]);
		}
		printf("\n%d %d\n", a, b);
	}
	fclose(fp);
	return 0;
}